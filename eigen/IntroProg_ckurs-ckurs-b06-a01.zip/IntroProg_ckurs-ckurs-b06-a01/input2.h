int lese_int();
void print_prim(int *array, int laenge);
